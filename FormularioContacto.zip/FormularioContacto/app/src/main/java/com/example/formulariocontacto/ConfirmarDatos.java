package com.example.formulariocontacto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ConfirmarDatos extends AppCompatActivity {

    public TextView tvNombre,tvFecha,tvTelefono,tvEmail,tvDescripcion;
    public Button btnEdicion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);

        tvNombre        = (TextView)findViewById(R.id.tvNombre);
        tvFecha         = (TextView)findViewById(R.id.tvFechaNacimiento);
        tvTelefono      = (TextView)findViewById(R.id.tvTelefono);
        tvEmail         = (TextView)findViewById(R.id.tvEmail);
        tvDescripcion   = (TextView)findViewById(R.id.tvDescripcion);
        btnEdicion      = (Button)findViewById(R.id.btnEditar);

        //Recibiendo parametros
        Bundle parametros = getIntent().getExtras();
        String nombre           = parametros.getString("DATA_NOMBRE_KEY");
        String fecha            = parametros.getString("DATA_FECHA_KEY");
        String telefono         = parametros.getString("DATA_TELEFONO_KEY");
        String email            = parametros.getString("DATA_EMAIL_KEY");
        String descripcion      = parametros.getString("DATA_DESCRIPCION_KEY");

        String cadnombre;
        String cadfecha;
        String cadtelefono;
        String cademail;
        String caddescripcion;

        //cadnombre = "Nombre: " + nombre;
        cadfecha = "Cumpleaños: " + fecha;
        cadtelefono = "Tel: " + telefono;
        cademail = "Email: " + email;
        caddescripcion = "Descripción: " + descripcion;

        tvNombre.setText(nombre);
        tvFecha.setText(cadfecha);
        tvTelefono.setText(cadtelefono);
        tvEmail.setText(cademail);
        tvDescripcion.setText(caddescripcion);
    }

    public void editarInfo(View v){
        Intent intent = new Intent(ConfirmarDatos.this,MainActivity.class);
        //intent.putExtra("NOMBRE_KEY", tvNombre.getText().toString());
        //intent.putExtra("FECHA_KEY",tvFecha.getText().toString());
        startActivity(intent);
        //finish();
    }

    public void backbtn(View view){
        super.onBackPressed();
    }
}
