package com.example.formulariocontacto;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    public EditText edtCalendario;
    public EditText edtNombre;
    public EditText edtTelefono;
    public EditText edtEmail;
    public EditText edtDescripcion;
    public Button btnSiguiente;

    private int anio,mes,dia;
    static final int DATE_ID = 0;
    Calendar calendario = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSiguiente = (Button) findViewById(R.id.btnSiguiente);
        edtNombre = (EditText) findViewById(R.id.edtNombre);
        edtTelefono = (EditText) findViewById(R.id.edtTelefono);
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        edtDescripcion = (EditText) findViewById(R.id.edtDescripcion);
        edtCalendario = (EditText) findViewById(R.id.edtCalendario);

        dia = calendario.get(Calendar.DAY_OF_MONTH);
        mes = calendario.get(Calendar.MONTH);
        anio = calendario.get(Calendar.YEAR);

        edtCalendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DATE_ID);
            }
        });


    }//OnCreate

    private void colocar_fecha(){
        edtCalendario.setText(dia + "/" + (mes + 1) + "/" + anio);
    }

    private DatePickerDialog.OnDateSetListener DateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            dia = dayOfMonth;
            mes = month;
            anio = year;
            colocar_fecha();
        }
    };

    protected Dialog onCreateDialog(int id){
        switch (id){
            case DATE_ID: return new DatePickerDialog(this, DateSetListener, dia,mes,anio);
        }
        return null;
    }


    public void envioParam(View v) {
        Intent intent = new Intent(MainActivity.this, ConfirmarDatos.class);
        //Exportar parametros
        intent.putExtra("DATA_NOMBRE_KEY", edtNombre.getText().toString());
        intent.putExtra("DATA_FECHA_KEY", edtCalendario.getText().toString());
        intent.putExtra("DATA_TELEFONO_KEY", edtTelefono.getText().toString());
        intent.putExtra("DATA_EMAIL_KEY", edtEmail.getText().toString());
        intent.putExtra("DATA_DESCRIPCION_KEY", edtDescripcion.getText().toString());
        startActivity(intent);
        finish();
    }
}